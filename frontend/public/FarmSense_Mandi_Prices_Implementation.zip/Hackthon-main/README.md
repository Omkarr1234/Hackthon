# AgriSaathi AI (Hackathon MVP)

AgriSaathi AI is a mobile-first bilingual (English/Kannada) web MVP focused on one crop (Tomato) with:
- Crop guidance
- AI-assisted plant image screening (demo mode)
- Simple farming Q&A assistant

> Important: Screening output is a **possible condition**, not a confirmed diagnosis.

## Project Structure

```
/home/runner/work/Hackthon/Hackthon
├── backend
│   ├── app
│   │   ├── api
│   │   ├── data
│   │   └── services
│   └── requirements.txt
└── frontend
    └── src
        ├── i18n
        └── services
```

## Tech Stack

- Frontend: React + Vite
- Backend: FastAPI
- Data: JSON + SQLite (screening logs)

## Run Backend

```bash
cd /home/runner/work/Hackthon/Hackthon/backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Backend URL: `http://localhost:8000`  
Docs: `http://localhost:8000/docs`

## Run Frontend

Open a new terminal:

```bash
cd /home/runner/work/Hackthon/Hackthon/frontend
npm install
npm run dev
```

Frontend URL: `http://localhost:5173`

## API Endpoints

- `GET /api/health`
- `GET /api/crops?lang=en|kn`
- `GET /api/crops/{cropId}/guide?lang=en|kn`
- `GET /api/conditions/{conditionId}?lang=en|kn`
- `POST /api/screening?lang=en|kn` (form-data: `crop_id`, `file`)
- `POST /api/chat?lang=en|kn` (JSON: `crop_id`, `question`)

## Troubleshooting

1. **CORS error in frontend**
   - Ensure backend is running on port `8000`.

2. **Upload rejected**
   - Use `.jpg`, `.jpeg`, or `.png` under 5MB.

3. **Backend import error**
   - Run from `/backend` and use `uvicorn app.main:app --reload --port 8000`.

4. **Port already in use**
   - Change frontend or backend port and update URL config if needed.


## Mandi Prices page

A separate Mandi Prices page is available in the main navigation. It calls `GET /api/mandi/prices` on the FastAPI backend and compares the latest returned modal price with the previous distinct dated record for the same commodity and market.

### Backend configuration

Set `DATA_GOV_API_KEY` in the backend hosting provider's environment variables. Get an API key from the Government of India's Open Government Data platform at https://data.gov.in/ . Do not place this key in frontend code or commit it to GitHub.

The endpoint uses the AGMARKNET daily market-price resource ID `9ef84268-d588-465a-a308-a864a43d0070`. Confirm the resource and fields remain available in your data.gov.in account. If the resource API returns different field names, adjust the normalization in `backend/app/api/routes.py`.

### Important

The comparison is between distinct dated records returned by the source, not necessarily consecutive calendar days. A missing previous record is displayed as unavailable. Market prices are not guaranteed farmer sale prices.
